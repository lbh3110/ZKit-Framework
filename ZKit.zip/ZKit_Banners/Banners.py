Banner1 = """

               @@@@@@@@                 @@@  @@@                 @@@                 @@@@@@@
               @@@@@@@@                 @@@  @@@                 @@@                 @@@@@@@
                    @@!                 @@!  !@@                 @@!                   @@!
                   !@!                  !@!  @!!                 !@!                   !@!
                  @!!                   @!@@!@!                  !!@                   @!!
                 !!!                    !!@!!!                   !!!                   !!!
                !!:                     !!: :!!                  !!:                   !!:
               :!:                      :!:  !:!                 :!:                   :!:
                :: ::::                  ::  :::                  ::                    ::
               : :: : :                  :   :::                 :                      :
                              {--!Github https://github.com/000Zer000/ZKit!--}
                                 {--{Trojan}{KeyLogger}{Dos}{Ransomware}--}
                                     {--!@#$%? Coded By Zer0 ?%$#@!--}
                                      {--Windows Pre-Release 0.9.0--}

""" 
Banner2 = 'Not Builded Right Now'